-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a202.p.ssafy.io    Database: chookbae
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_user`
--

DROP TABLE IF EXISTS `accounts_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb3_bin NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb3_bin NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `nickname` varchar(11) COLLATE utf8mb3_bin NOT NULL,
  `profile_image` longtext COLLATE utf8mb3_bin,
  `login_count` int NOT NULL,
  `points` int NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user`
--

LOCK TABLES `accounts_user` WRITE;
/*!40000 ALTER TABLE `accounts_user` DISABLE KEYS */;
INSERT INTO `accounts_user` VALUES (35,'pbkdf2_sha256$260000$g0qMRVoVkYxOa38Vs9weAm$9cGnRGiycFei5DDCKwwYE5D7NgbrKRGqMLo5qf7BzBY=','2022-11-18 15:53:46.177652','soo930810@naver.com',1,'lastCheck','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/3d9b156e5f1e11ed87140242c0a81002',10,500000,100572),(36,'pbkdf2_sha256$260000$bbhdPgTafFN4laAjWfOsoL$ughFmmGdhumBnmdXbNiUD+udHGi7VtgAgQJubzcpzIk=','2022-11-18 10:06:44.763646','qkftkftnf@naver.com',1,'qoqo','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/9920138466e511edaa190242ac190002',10,500000,3719312),(38,'pbkdf2_sha256$260000$UIpsTucAiePEej7KwPFXDv$czfXrkzUmIJawfQKG6gCQ17F+5Q1LkmePN6/AklJRMc=','2022-11-17 18:56:29.882467','jelee6613@naver.com',1,'asdasd','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/dded83b063f311ed98880242c0a8f002',9,500000,69682),(62,'pbkdf2_sha256$260000$RzuRCtvxvK3psn8GOYHTWX$tOxwVFecUwki+FPuI3XlWFqD3SGXVfYgN+I97FSkCdw=','2022-11-18 11:05:45.400059','suwhan1992@gmail.com',1,'싸피와싸커','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/b6303fe466e511ed9d660242ac190002',8,500000,3602038),(64,'pbkdf2_sha256$260000$0oWCtlkSrOAz7ap7UaWVbZ$zvzaNQA0ojWCHn+OoFBBT6xR2AzycBRthPZ2yvbnyhE=','2022-11-11 16:48:19.458547','tim96030@naver.com',1,'경은아저씨','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/0c9a994e609011eda95c0242c0a8e002',2,500000,0),(87,'pbkdf2_sha256$260000$QzHf7xV0MIqwDKytiVTybf$3j+P9a4MhkUbnfRMlxABQD2TRMrM//ChCve7AFZ7hKY=','2022-11-18 10:57:34.439412','tim9606@naver.com',1,'testtett7','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/0ab010c45f1811ed8ffe0242c0a80002',3,500000,2063783),(111,'pbkdf2_sha256$260000$QcHCuzKz9ca4Oi8jUBcIrJ$OI+3LmaSLsbpN9uxLrxOEA0DXvM3mwOtQH95uWhzGZs=','2022-11-17 17:15:37.888855','wlgnstjd0717@gmail.com',1,'jihoon','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/0ab010c45f1811ed8ffe0242c0a80002',3,500000,1445252),(144,'pbkdf2_sha256$260000$DUJrem19U5KBLbmFmYasIi$iHq8bHA0YeopU+f4wYGS2gZDD3Jd0fNgHV72jZgztB4=','2022-11-17 10:14:59.860338','nirarang@naver.com',1,'Saaa','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/0ab010c45f1811ed8ffe0242c0a80002',1,500000,0),(145,'pbkdf2_sha256$260000$R41dMdmH4hdnOrIKAlXKBA$uob6dseHeZ1gXQxhXZ3dy1TxtJKoUdf/RyMsei+CUqU=','2022-11-17 10:43:06.991170','ssafy1@ssafy.com',1,'ssafy1','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/0ab010c45f1811ed8ffe0242c0a80002',1,500000,310418),(147,'pbkdf2_sha256$260000$pAVAEadcgKVFvxl2d09zaE$rZisF/QbeChDHMszLoMxMIq9I4OXiQIOLk5Qgo6MF5U=','2022-11-17 17:45:57.848295','tim9607@naver.com',1,'ssafy007','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/0ab010c45f1811ed8ffe0242c0a80002',1,500000,289700),(148,'pbkdf2_sha256$260000$8y4TaDPZnSEcEfiRv60cCv$yep1A698nhEMtuKVrwGo6JdoAiM2l7wazXQa6henrCU=','2022-11-17 17:47:32.845059','tim9608@naver.com',1,'ssafy002','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/0ab010c45f1811ed8ffe0242c0a80002',1,500000,114763),(150,'pbkdf2_sha256$260000$toO67rR8yaoZSx7dYaIKrg$qYcWr3fqlC1tczodw1Q0BqIAq8dlDF6HUvyBsA50duY=','2022-11-18 13:58:30.695909','ssafy07@ssafy.com',1,'카타르가자','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/04a8581066fe11ed959b0242ac190002',1,500000,496904),(151,'pbkdf2_sha256$260000$6js9aJNHGGA4WBA0g54Rh4$WVstNhcJ5HCHjuGfGWhEXIg3MAov9RHZKFu4tSFBsZI=','2022-11-18 11:40:53.911375','syong0716@naver.com',1,'gg','https://chookbae.s3.ap-northeast-1.amazonaws.com/img/0ab010c45f1811ed8ffe0242c0a80002',1,500000,77026);
/*!40000 ALTER TABLE `accounts_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 17:31:27
