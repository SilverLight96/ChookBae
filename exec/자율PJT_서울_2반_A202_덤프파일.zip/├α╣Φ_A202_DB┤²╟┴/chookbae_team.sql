-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a202.p.ssafy.io    Database: chookbae
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` int NOT NULL,
  `country` varchar(200) COLLATE utf8mb3_bin NOT NULL,
  `logo` longtext COLLATE utf8mb3_bin,
  `group` varchar(200) COLLATE utf8mb3_bin NOT NULL,
  `rank` int NOT NULL,
  `win` int NOT NULL,
  `draw` int NOT NULL,
  `loss` int NOT NULL,
  `points` int NOT NULL,
  `last_five` varchar(200) COLLATE utf8mb3_bin NOT NULL,
  `goal_diff` int NOT NULL,
  `manager` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `round` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (377,'Belgium','https://api.statorium.com/media/bearleague/bl15773718381034.png','F',0,0,0,0,0,'5 games',0,'Roberto Martínez',0),(378,'Croatia','https://api.statorium.com/media/bearleague/bl1577371896327.png','F',0,0,0,0,0,'5 games',0,'Zlatko Dalić',0),(380,'Denmark','https://api.statorium.com/media/bearleague/bl15773729721493.png','D',0,0,0,0,0,'5 games',0,'Kasper Hjulmand',0),(381,'England','https://api.statorium.com/media/bearleague/bl1577372003565.png','B',0,0,0,0,0,'5 games',0,'Gareth Southgate',0),(383,'France','https://api.statorium.com/media/bearleague/bl1577372084968.png','D',0,0,0,0,0,'5 games',0,'Didier Deschamps',0),(384,'Germany','https://api.statorium.com/media/bearleague/bl1577372120734.png','E',0,0,0,0,0,'5 games',0,'Hansi Flick',0),(385,'Netherlands','https://api.statorium.com/media/bearleague/bl15773721822574.png','A',0,0,0,0,0,'5 games',0,'Louis van Gaal',0),(386,'Poland','https://api.statorium.com/media/bearleague/bl15773722262695.png','C',0,0,0,0,0,'5 games',0,'Czesław Michniewicz',0),(387,'Portugal','https://api.statorium.com/media/bearleague/bl15773722612930.png','H',0,0,2,1,2,'5 games',-1,'Fernando Santos',0),(389,'Spain','https://api.statorium.com/media/bearleague/bl1577372316786.png','E',0,0,0,0,0,'5 games',0,'Luis Enrique',0),(391,'Switzerland','https://api.statorium.com/media/bearleague/bl1577372370179.png','G',0,0,0,0,0,'5 games',0,'Murat Yakin',0),(394,'Wales','https://api.statorium.com/media/bearleague/bl15773726101395.png','B',0,0,0,0,0,'5 games',0,'Rob Page',0),(426,'Brazil','https://api.statorium.com/media/bearleague/bl15791624691418.png','G',0,0,0,0,0,'5 games',0,'Adenor Leonardo Bacchi',0),(427,'Argentina','https://api.statorium.com/media/bearleague/bl15791625082286.png','C',0,0,0,0,0,'5 games',0,'Lionel Scaloni',0),(428,'Australia','https://api.statorium.com/media/bearleague/bl1579162540127.png','D',0,0,0,0,0,'5 games',0,'Graham Arnold',0),(430,'Uruguay','https://api.statorium.com/media/bearleague/bl15791626432037.png','H',0,2,1,0,7,'5 games',2,'Diego Alonso',0),(434,'Qatar','https://api.statorium.com/media/bearleague/bl1579162808884.png','A',0,0,0,0,0,'5 games',0,'Félix Sánchez',0),(436,'Ecuador','https://api.statorium.com/media/bearleague/bl1579162865567.png','A',0,0,0,0,0,'5 games',0,'Gustavo Alfaro',0),(670,'Serbia','https://api.statorium.com/media/bearleague/bl160041601223.png','G',0,0,0,0,0,'5 games',0,'Dragan Stojković',0),(1046,'Tunisia','https://api.statorium.com/media/bearleague/bl16324025802633.png','D',0,0,0,0,0,'5 games',0,'Jalel Kadri',0),(1055,'Cameroon','https://api.statorium.com/media/bearleague/bl16324021582342.png','G',0,0,0,0,0,'5 games',0,'Rigobert Song',0),(1063,'Ghana','https://api.statorium.com/media/bearleague/bl16324022962769.png','H',0,0,1,2,1,'5 games',-4,'Otto Addo',0),(1066,'Senegal','https://api.statorium.com/media/bearleague/bl1632402538827.png','A',0,0,0,0,0,'5 games',0,'Aliou Cissé',0),(1071,'Morocco','https://api.statorium.com/media/bearleague/bl16324024822592.png','F',0,0,0,0,0,'5 games',0,'Walid Regragui',0),(1227,'Iran','https://api.statorium.com/media/bearleague/bl1643370435894.png','B',0,0,0,0,0,'5 games',0,'Carlos Queiroz',0),(1235,'South Korea','https://api.statorium.com/media/bearleague/bl1644737502559.png','H',0,1,2,0,5,'5 games',1,'Paulo Bento',0),(1236,'Japan','https://api.statorium.com/media/bearleague/bl16484881531369.png','E',0,0,0,0,0,'5 games',0,'Hajime Moriyasu',0),(1237,'Saudi Arabia','https://api.statorium.com/media/bearleague/bl16484892121.png','C',0,0,0,0,0,'5 games',0,'Hervé Renard',0),(1242,'Canada','https://api.statorium.com/media/bearleague/bl16487182872522.png','F',0,0,0,0,0,'5 games',0,'John Herdman',0),(1243,'United States of America','https://api.statorium.com/media/bearleague/bl1648719010303.png','B',0,0,0,0,0,'5 games',0,'Gregg Berhalter',0),(1244,'Mexico','https://api.statorium.com/media/bearleague/bl1648836370899.png','C',0,0,0,0,0,'5 games',0,'Gerardo Martino',0),(1278,'Costa Rica','https://api.statorium.com/media/bearleague/bl16545307132101.png','E',0,0,0,0,0,'5 games',0,'Luis Fernando Suárez',0);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 17:31:26
