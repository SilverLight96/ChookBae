-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a202.p.ssafy.io    Database: chookbae
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venue` (
  `id` int NOT NULL,
  `venue_name` varchar(200) COLLATE utf8mb3_bin NOT NULL,
  `venue_image` longtext COLLATE utf8mb3_bin,
  `address` varchar(200) COLLATE utf8mb3_bin NOT NULL,
  `capacity` int NOT NULL,
  `opened_year` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue`
--

LOCK TABLES `venue` WRITE;
/*!40000 ALTER TABLE `venue` DISABLE KEYS */;
INSERT INTO `venue` VALUES (710,'Ahmad bin Ali Stadium (Al-Rayyan Stadium)','https://api.statorium.com/media/bearleague/bl16033617181364.jpg','Umm Al Afaei, Al Rayyan, Qatar',40740,2003),(712,'Al Janoub Stadium','https://api.statorium.com/media/bearleague/bl16033620372032.jpg','Al Wukair, Qatar',40000,2019),(1163,'Al Bayt Stadium','https://api.statorium.com/media/bearleague/bl16497805962036.jpg','MF2Q+V4Q, Al Khor, Qatar',60000,2021),(1164,'Lusail Stadium','https://api.statorium.com/media/bearleague/bl16498615411401.jpeg','CFCR+75، لوسيل،، Qatar',80000,2021),(1165,'Stadium 974','https://api.statorium.com/media/bearleague/bl16498622422039.jpg','Ras Abu Abboud, Doha, Qatar',40000,2021),(1166,'Khalifa International Stadium','https://api.statorium.com/media/bearleague/bl16507941612225.jpg','7C7X+C67, Al Waab St, Doha, Qatar',45416,1976),(1167,'Education City Stadium','https://api.statorium.com/media/bearleague/bl1649782543450.jpg','8C6F+8Q7, Ar Rayyan, Qatar',45350,2020),(1168,'Al Thumama Stadium','https://api.statorium.com/media/bearleague/bl16497809351071.jpg','Al Thumama, Doha, Qatar',40000,2021);
/*!40000 ALTER TABLE `venue` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 17:31:27
